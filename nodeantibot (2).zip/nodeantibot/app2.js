const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const PORT = 3000;
const accessKey = '6ab55542a38d1a'; // Replace with your ipapi.com access key

app.use(cors());

app.get('/check-access', async (req, res) => {
  const clientIP = req.headers['x-forwarded-for'] || req.connection.remoteAddress;

  try {
    const response = await axios.get(`https://ipapi.co/${clientIP}/json?key=${accessKey}`);
    const data = response.data;
    res.json(data);
  } catch (error) {
    console.error('Error fetching geolocation data:', error);
    res.status(500).json({ error: 'Error fetching geolocation data' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
