const express = require('express');
const request = require('request-promise');
const app = express();
const port = 3000;

const allowedCountries = ['US', 'CA'];
const accessKey = '6ab55542a38d1a';

app.get('/check-access', async (req, res) => {
  const userIP = req.headers['x-forwarded-for'] || req.connection.remoteAddress;

  try {
    const response = await request({
      uri: `https://ipinfo.io/${userIP}/json?token=${accessKey}`,
      json: true,
    });

    const isDataCenterOrVPN = response.hostname && response.hostname.includes('hosting');
    const isAllowedCountry = allowedCountries.includes(response.country);
    const isAllowed = isAllowedCountry && !isDataCenterOrVPN;

    res.json({ allowed: isAllowed });
  } catch (error) {
    console.error('Error fetching geolocation data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.listen(port, () => {
  console.log(`Access control API listening at http://localhost:${port}`);
});
